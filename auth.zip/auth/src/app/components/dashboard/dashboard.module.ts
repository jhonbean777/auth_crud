import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ToastrModule } from 'ngx-toastr';
import { ModalModule } from 'ngx-bootstrap/modal';
import { StudentComponent } from '../student/student.component';
import { AddEditStudentComponent } from '../student/add-edit-student/add-edit-student.component';
import { DeleteStudentComponent } from '../student/delete-student/delete-student.component';
import { DashboardComponent } from './dashboard.component';
import { CommonModule } from '@angular/common';
import { AuthGuard } from 'src/app/shared/helpers/auth.guard';

const dashboardRoutes: Routes = [{
    path: 'dashboard',
    component: DashboardComponent,
    children: [
        { path: 'student', component: StudentComponent, canActivate: [AuthGuard] }
    ], canActivate: [AuthGuard]
}];


@NgModule({
    declarations: [
        StudentComponent,
        AddEditStudentComponent,
        DeleteStudentComponent
    ],
    imports: [
        RouterModule.forChild(dashboardRoutes),
        BrowserAnimationsModule,
        ReactiveFormsModule,
        HttpClientModule,
        NgxDatatableModule,
        ModalModule.forRoot(),
        ToastrModule.forRoot(),
        CommonModule
    ],
    exports: [RouterModule]
})
export class DashboardModule { }
