import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  public name = "Aarti";
  public userName : any ="";
  constructor(private router : Router){}
  ngOnInit(){
    this.userName = localStorage.getItem('userName');
  }
  public logOut (): void{
    localStorage.removeItem('userName');
    this.router.navigate(['/login'])
  }
}
