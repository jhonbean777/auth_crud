import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { StudentService } from 'src/app/shared/services/student.service';
import { DeleteStudentComponent } from './delete-student/delete-student.component';
import { AddEditStudentComponent } from './add-edit-student/add-edit-student.component';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.scss']
})
export class StudentComponent implements OnInit {
  public totalCount: number = 0;
  public students: any[] = [];
  public addEditStudentModal!: BsModalRef;
  public deleteStudentModal!: BsModalRef;

  constructor(
    private studentService: StudentService,
    private toastrService: ToastrService,
    private modalService: BsModalService
  ) { }

  ngOnInit() {
    this.loadTeachers();
  }

  loadTeachers(): void {
    this.studentService.getStudents().subscribe((response: any) => {
      this.students = response;
      this.totalCount = this.students.length;
    }, (error: any) => {
      this.toastrService.error("Error loading students list", "Error");
    }
    )
  }

  public openAddEditStudentsModal(students: any = null): void {
    this.addEditStudentModal = this.modalService.show(AddEditStudentComponent, {
      initialState: { student: students }, class: "modal-lg",
      ignoreBackdropClick: true
    });
    this.addEditStudentModal.content.close.subscribe(() => {
      this.addEditStudentModal.hide();
      this.loadTeachers();
    })
  }

  public openDeleteStudentsModal(students: any = null): void {
    this.deleteStudentModal = this.modalService.show(DeleteStudentComponent, {
      initialState: { student: students }, class: "modal-lg",
      ignoreBackdropClick: true
    });
    this.deleteStudentModal.content.close.subscribe(() => {
      this.deleteStudentModal.hide();
      this.loadTeachers();
    })

  }

}










