import { Component, Input, Output, EventEmitter } from '@angular/core';
import { StudentService } from 'src/app/shared/services/student.service';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Validators } from '@angular/forms';
@Component({
  selector: 'app-add-edit-student',
  templateUrl: './add-edit-student.component.html',
  styleUrls: ['./add-edit-student.component.scss']
})
export class AddEditStudentComponent {
  @Input() student: any;
  @Output() close = new EventEmitter();

  public studentForm = new FormGroup(
    {
      acceptTerms: new FormControl(""),
      firstName: new FormControl("", [Validators.required, Validators.maxLength(10), Validators.minLength(3)]),
      lastName: new FormControl("", [Validators.required, Validators.maxLength(10), Validators.minLength(3)]),
      email: new FormControl("", [Validators.required, Validators.pattern(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/)]),
      city: new FormControl("", [Validators.required]),
      gender: new FormControl("", [Validators.required]),
      class: new FormControl("", [Validators.required]),
      phone: new FormControl("", [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
    }
  )
  constructor(private studentService: StudentService,
    private toastrService: ToastrService
  ) { }

  ngOnInit() {
    if (this.student) {
      this.studentForm.patchValue(this.student);
    }
  }

  public onClose(): void {
    this.close.emit();
  }

  public save(): void {
    let payload = this.assignValueToModel();
    if (!this.student) {
      this.addProduct(payload);
    } else {
      this.updateProduct(payload);
    }
  }

  private addProduct(payload: any): void {
    this.studentService.addStudent(payload).subscribe((response: any) => {
      this.toastrService.success("Teacher added successfully", "success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("Error adding teacher", "Error")
    }
    );
  }
  private updateProduct(payload: any): void {
    this.studentService.updateStudent(payload).subscribe((response: any) => {
      this.toastrService.success("Teacher updated successfully", "success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("Error updating product", "Error")
    });
  }
  public checkIfControlValid(controlName: string): any {
    return this.studentForm.get(controlName)?.invalid &&
      this.studentForm.get(controlName)?.errors &&
      (this.studentForm.get(controlName)?.dirty || this.studentForm.get(controlName)?.touched);

  }
  public checkControlHasError(controlName: string, error: string): any {
    return this.studentForm.get(controlName)?.hasError(error);
  }

  private assignValueToModel(): any {
    let student = {
      "id": this.student ? this.student.id : 0,
      "firstName": this.studentForm.get("firstName")?.value,
      "lastName": this.studentForm.get("lastName")?.value,
      "email": this.studentForm.get("email")?.value,
      "phone": this.studentForm.get("phone")?.value,
      "gender": this.studentForm.get("gender")?.value,
      "city": this.studentForm.get("city")?.value,
      "acceptTerms": this.studentForm.get("acceptTerms")?.value,
    }
    return student;
  }
}
