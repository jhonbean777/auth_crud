import { StudentService } from 'src/app/shared/services/student.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup } from '@angular/forms';
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-delete-student',
  templateUrl: './delete-student.component.html',
  styleUrls: ['./delete-student.component.scss']
})
export class DeleteStudentComponent {
  @Input() student: any;
  @Output() close = new EventEmitter();

  public studentForm = new FormGroup({
    name: new FormControl(""),
    description: new FormControl(""),
    price: new FormControl(""),
  });

  constructor(
    private studentService: StudentService,
    private toastrService: ToastrService,
    public bsModalRef: BsModalRef
  ) { }

  ngOnInit() {
    if (this.student) {
      this.studentForm.patchValue(this.student);
    }
  }

  public onClose(): void {
    this.close.emit();
    this.bsModalRef.hide();
  }

  // public yes(): void {
  //   this.confirmDelete();
  // }

  // private confirmDelete(): void {
  //   const confirmed = confirm("Are you sure you want to delete this product?");
  //   if (confirmed) {
  //     this.performDelete();
  //   }
  // }

  public performDelete(): void {
    let payload = this.assignValueToModel();
    this.studentService.deleteStudent(payload).subscribe((response: any) => {
      this.toastrService.success("product deleted successfully", "success");
      this.onClose();
    }, (error: any) => {
      this.toastrService.error("Error deleting teacher", "Error")
    }
    );
  }

  private assignValueToModel(): any {
    let student = {
      "id": this.student ? this.student.id : 0,
      "name": this.studentForm.get("name")?.value,
      "description": this.studentForm.get("description")?.value,
      "price": this.studentForm.get("price")?.value
    }
    return student;
  }
}


