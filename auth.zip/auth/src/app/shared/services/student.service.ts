import { Injectable } from '@angular/core';
import { from, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private httpClient: HttpClient) { }

  public getStudents(): any {
    return this.httpClient.get(`http://localhost:3000/students`)
  }

  public addStudent(student: any): any {
    return this.httpClient.post(`http://localhost:3000/students`, student)
  }
  public updateStudent(student: any): any {
    return this.httpClient.put(`http://localhost:3000/students/${student.id}`, student)
  }
  public deleteStudent(student: any): any {
    return this.httpClient.delete(`http://localhost:3000/students/${student.id}`, student)
  }

}


